# IOSControl USB Manager

Kết nối và điều khiển nhiều iPhone qua USB từ máy tính Windows/Mac.

---

## 🔧 Yêu cầu

### Trên iPhone (mỗi máy)
- Jailbreak (Dopamine/Palera1n)  
- Cài **IOSControl** từ Sileo (source: `https://ioscontrol.com/repo`)

### Trên máy tính

**Windows:**
- iTunes đã cài (cho USB drivers)
- File `ioscontrol-usb.bat` (có sẵn trong thư mục này)

**Mac:**
- Homebrew: `brew install libimobiledevice`
- File `ioscontrol-usb.sh` (có sẵn trong thư mục này)

---

## 🚀 Cách dùng

### Bước 1: Cắm iPhone vào máy tính qua USB
Dùng USB Hub nếu có nhiều iPhone. Mỗi iPhone cần 1 cáp Lightning/USB-C.

### Bước 2: Chạy script

**Windows:** Double-click `ioscontrol-usb.bat`

**Mac:**
```bash
chmod +x ioscontrol-usb.sh
./ioscontrol-usb.sh
```

### Bước 3: Mở trình duyệt
Script sẽ hiện danh sách iPhone và port tương ứng:
```
[+] iPhone 1 (slot 0) -> IDE: http://localhost:9999
[+] iPhone 2 (slot 1) -> IDE: http://localhost:9991  
[+] iPhone 3 (slot 2) -> IDE: http://localhost:9992
```

Mở trình duyệt → nhập `http://localhost:9999` → Web IDE của iPhone 1.

### Bước 4: Xem trên app iPhone
Mở app **iControlApp** trên iPhone → dưới mục IP Address sẽ hiện dòng:
```
🔗 USB IDE: http://localhost:9999
```
Nhấn vào để copy link.

---

## 📋 Port Mapping

| iPhone | IDE URL | VNC |
|--------|---------|-----|
| #1 (slot 0) | `http://localhost:9999` | `localhost:15900` |
| #2 (slot 1) | `http://localhost:9991` | `localhost:15910` |
| #3 (slot 2) | `http://localhost:9992` | `localhost:15920` |
| #4 (slot 3) | `http://localhost:9993` | `localhost:15930` |
| ... | `http://localhost:999X` | `localhost:159X0` |

---

## ❓ FAQ

**Q: Cắm rút iPhone có cần restart script không?**  
A: Không. Script tự phát hiện kết nối/ngắt kết nối mỗi 3 giây.

**Q: Hỗ trợ bao nhiêu iPhone?**  
A: Không giới hạn. Thực tế tuỳ số cổng USB và RAM của máy tính.

**Q: iPhone respring thì sao?**  
A: USB IDE tự hiện lại trong 5 giây, không cần làm gì.

**Q: Windows báo "iproxy not found"?**  
A: Cài iTunes. Nếu vẫn lỗi, tải libimobiledevice:
https://github.com/libimobiledevice-win32/imobiledevice-net/releases
Extract → bỏ file .exe vào thư mục `tools\` cạnh file .bat.

**Q: Dùng qua WiFi hay USB nhanh hơn?**  
A: USB nhanh hơn ~5x và ổn định hơn (không phụ thuộc mạng WiFi).
