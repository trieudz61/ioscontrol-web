@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul 2>&1
title IOSControl USB Manager
color 0A

echo.
echo  ===================================================
echo   IOSControl USB Manager for Windows
echo   Supports unlimited iPhones via USB
echo  ===================================================
echo.

:: ── Config ──
set "TOOLS_DIR=%~dp0tools"
set "DATA_DIR=%USERPROFILE%\.ioscontrol"
set "POLL_INTERVAL=3"
set "IPROXY=iproxy"
set "IDEVICE_ID=idevice_id"
set "IDEVICEINFO=ideviceinfo"

:: Try system PATH first
where iproxy >nul 2>&1
if %ERRORLEVEL% neq 0 (
    if exist "%TOOLS_DIR%\iproxy.exe" (
        set "IPROXY=%TOOLS_DIR%\iproxy.exe"
        set "IDEVICE_ID=%TOOLS_DIR%\idevice_id.exe"
        set "IDEVICEINFO=%TOOLS_DIR%\ideviceinfo.exe"
    ) else (
        echo  [ERROR] iproxy.exe not found!
        echo.
        echo  Please do ONE of these:
        echo    1. Put iproxy.exe, idevice_id.exe in a 'tools' folder next to this script
        echo    2. Install via: choco install imobiledevice-net
        echo    3. Download from: https://github.com/libimobiledevice-win32/imobiledevice-net/releases
        echo.
        echo  Also make sure iTunes or Apple Mobile Device Support is installed.
        echo.
        pause
        exit /b 1
    )
)

:: Create data dirs
if not exist "%DATA_DIR%\pids" mkdir "%DATA_DIR%\pids"
if not exist "%DATA_DIR%\slots" mkdir "%DATA_DIR%\slots"
if not exist "%DATA_DIR%\active" mkdir "%DATA_DIR%\active"
if not exist "%DATA_DIR%\names" mkdir "%DATA_DIR%\names"

echo  [OK] Dependencies found
echo  [..] Scanning for iPhones...
echo.

:: ── Main loop ──
:main_loop

:: Get connected devices and check new ones
for /f "delims=" %%D in ('!IDEVICE_ID! -l 2^>nul') do (
    if not "%%D"=="" (
        if not exist "%DATA_DIR%\active\%%D" (
            call :start_device "%%D"
        )
    )
)

:: Detect disconnections
for %%F in ("%DATA_DIR%\active\*") do (
    if exist "%%F" (
        set "STILL_CONNECTED=0"
        for /f "delims=" %%D in ('!IDEVICE_ID! -l 2^>nul') do (
            if "%%~nxF"=="%%D" set "STILL_CONNECTED=1"
        )
        if "!STILL_CONNECTED!"=="0" (
            call :stop_device "%%~nxF"
        )
    )
)

:: Re-register USB ports with all active devices
for %%F in ("%DATA_DIR%\slots\*") do (
    if exist "%%F" (
        set /p RE_SLOT=<"%%F"
        call :get_port !RE_SLOT!
        start /b "" cmd /c "curl -s -m 2 "http://localhost:!PORT_RESULT!/api/usb/register?ide_url=http://localhost:!PORT_RESULT!" >nul 2>&1"
    )
)

timeout /t %POLL_INTERVAL% /nobreak >nul
goto main_loop

:: ════════════════════════════════════════════
:: Functions
:: ════════════════════════════════════════════

:start_device
set "S_UDID=%~1"
if "%S_UDID%"=="" exit /b

:: Mark active
echo.>"%DATA_DIR%\active\%S_UDID%"

:: Assign slot
call :assign_slot "%S_UDID%"
set "S_SLOT=!SLOT_RESULT!"

:: Calculate ports
call :get_port !S_SLOT!
set "S_HTTP=!PORT_RESULT!"
set /a "S_VNC_RFB=15900 + !S_SLOT! * 10"
if "!S_SLOT!"=="0" (set "S_VNC_WS=5902") else (set /a "S_VNC_WS=5902 + !S_SLOT! * 10")

:: Get device name
set "S_NAME=iPhone"
for /f "delims=" %%N in ('!IDEVICEINFO! -u %S_UDID% -k DeviceName 2^>nul') do set "S_NAME=%%N"
echo !S_NAME!>"%DATA_DIR%\names\%S_UDID%"

echo  [+] !S_NAME! ^(slot !S_SLOT!^) -^> IDE: http://localhost:!S_HTTP!

:: Kill stale processes on ports
for %%P in (!S_HTTP! !S_VNC_WS! !S_VNC_RFB!) do (
    for /f "tokens=5" %%A in ('netstat -ano 2^>nul ^| findstr ":%%P "') do (
        taskkill /PID %%A /F >nul 2>&1
    )
)
timeout /t 1 /nobreak >nul

:: Start iproxy tunnels
start "" /b !IPROXY! !S_HTTP!:9999 -u %S_UDID% >nul 2>&1
start "" /b !IPROXY! !S_VNC_WS!:5902 -u %S_UDID% >nul 2>&1
start "" /b !IPROXY! !S_VNC_RFB!:5900 -u %S_UDID% >nul 2>&1

:: Register after 3s delay
start "" /b cmd /c "timeout /t 3 /nobreak >nul & curl -s -m 5 "http://localhost:!S_HTTP!/api/usb/register?ide_url=http://localhost:!S_HTTP!" >nul 2>&1"

exit /b

:stop_device
set "D_UDID=%~1"
set "D_SHORT=!D_UDID:~0,8!"
echo  [-] Disconnected: !D_SHORT!...

:: Remove tracking files
del "%DATA_DIR%\active\%D_UDID%" 2>nul
del "%DATA_DIR%\slots\%D_UDID%" 2>nul
del "%DATA_DIR%\names\%D_UDID%" 2>nul
exit /b

:assign_slot
set "A_UDID=%~1"
:: Check existing slot
if exist "%DATA_DIR%\slots\%A_UDID%" (
    set /p SLOT_RESULT=<"%DATA_DIR%\slots\%A_UDID%"
    exit /b
)
:: Find free slot
for /l %%I in (0,1,99) do (
    set "SLOT_USED=0"
    for %%F in ("%DATA_DIR%\slots\*") do (
        if exist "%%F" (
            set /p CHECK_SLOT=<"%%F"
            if "!CHECK_SLOT!"=="%%I" set "SLOT_USED=1"
        )
    )
    if "!SLOT_USED!"=="0" (
        echo %%I>"%DATA_DIR%\slots\%A_UDID%"
        set "SLOT_RESULT=%%I"
        exit /b
    )
)
set "SLOT_RESULT=0"
exit /b

:get_port
if "%1"=="0" (set "PORT_RESULT=9999") else (set /a "PORT_RESULT=9990 + %1")
exit /b
