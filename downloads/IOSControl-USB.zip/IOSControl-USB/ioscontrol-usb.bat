@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul 2>&1
title IOSControl USB Manager
color 0A

echo.
echo  ===================================================
echo   IOSControl USB Manager for Windows
echo  ===================================================
echo.

:: ── Find tools ──
set "TOOLS_DIR=%~dp0tools"
set "IPROXY=%TOOLS_DIR%\iproxy.exe"
set "IDEVICE_ID=%TOOLS_DIR%\idevice_id.exe"
set "IDEVICEINFO=%TOOLS_DIR%\ideviceinfo.exe"

:: Check if tools exist in tools/ folder
if not exist "!IPROXY!" (
    :: Try system PATH
    where iproxy >nul 2>&1
    if !ERRORLEVEL! equ 0 (
        set "IPROXY=iproxy"
        set "IDEVICE_ID=idevice_id"
        set "IDEVICEINFO=ideviceinfo"
    ) else (
        echo  [ERROR] iproxy.exe not found!
        echo.
        echo  Put iproxy.exe, idevice_id.exe in the 'tools' folder
        echo  next to this .bat file.
        echo.
        pause
        exit /b 1
    )
)

echo  [OK] Tools found: !IPROXY!

:: Check iTunes / Apple Mobile Device
"!IDEVICE_ID!" -l >nul 2>&1
if !ERRORLEVEL! neq 0 (
    echo  [WARN] Cannot detect devices. Make sure iTunes is installed.
)

:: ── Setup ──
set "DATA_DIR=%USERPROFILE%\.ioscontrol"
if not exist "!DATA_DIR!\slots" mkdir "!DATA_DIR!\slots" 2>nul
if not exist "!DATA_DIR!\active" mkdir "!DATA_DIR!\active" 2>nul
if not exist "!DATA_DIR!\names" mkdir "!DATA_DIR!\names" 2>nul

echo  [OK] Data dir: !DATA_DIR!
echo.
echo  Scanning for iPhones every 3 seconds...
echo  Press Ctrl+C to stop.
echo.
echo  ---------------------------------------------------

:: ── Main loop ──
:loop

:: List connected devices
set "DEV_COUNT=0"
for /f "usebackq delims=" %%D in (`"!IDEVICE_ID!" -l 2^>nul`) do (
    set "UDID=%%D"
    if not "!UDID!"=="" (
        set /a DEV_COUNT+=1
        if not exist "!DATA_DIR!\active\!UDID!" (
            call :new_device "!UDID!"
        )
    )
)

:: Check for disconnections
for %%F in ("!DATA_DIR!\active\*") do (
    if exist "%%F" (
        set "CHECK_UDID=%%~nxF"
        set "STILL_HERE=0"
        for /f "usebackq delims=" %%D in (`"!IDEVICE_ID!" -l 2^>nul`) do (
            if "!CHECK_UDID!"=="%%D" set "STILL_HERE=1"
        )
        if "!STILL_HERE!"=="0" (
            echo  [-] Disconnected: !CHECK_UDID:~0,8!...
            del "!DATA_DIR!\active\!CHECK_UDID!" 2>nul
            del "!DATA_DIR!\slots\!CHECK_UDID!" 2>nul
        )
    )
)

:: Re-register USB port with all active devices
for %%F in ("!DATA_DIR!\slots\*") do (
    if exist "%%F" (
        set /p RSLOT=<"%%F"
        call :calc_port !RSLOT!
        start "" /b cmd /c "curl -s -m 2 "http://localhost:!CALC_PORT!/api/usb/register?ide_url=http://localhost:!CALC_PORT!" >nul 2>&1"
    )
)

timeout /t 3 /nobreak >nul
goto loop

:: ════════════════════════════════════════════
:new_device
set "ND_UDID=%~1"
if "!ND_UDID!"=="" exit /b

:: Mark active
echo.>"!DATA_DIR!\active\!ND_UDID!"

:: Find free slot
set "ND_SLOT=0"
for /l %%I in (0,1,99) do (
    set "SLOT_FREE=1"
    for %%S in ("!DATA_DIR!\slots\*") do (
        if exist "%%S" (
            set /p USED=<"%%S"
            if "!USED!"=="%%I" set "SLOT_FREE=0"
        )
    )
    if "!SLOT_FREE!"=="1" (
        set "ND_SLOT=%%I"
        echo %%I>"!DATA_DIR!\slots\!ND_UDID!"
        goto :slot_found
    )
)
:slot_found

:: Calculate ports
call :calc_port !ND_SLOT!
set "ND_HTTP=!CALC_PORT!"
set /a "ND_VNC=15900 + !ND_SLOT! * 10"

:: Get device name
set "ND_NAME=iPhone"
for /f "usebackq delims=" %%N in (`"!IDEVICEINFO!" -u !ND_UDID! -k DeviceName 2^>nul`) do (
    if not "%%N"=="" set "ND_NAME=%%N"
)

echo.
echo  [+] !ND_NAME!
echo      Slot: !ND_SLOT!
echo      IDE:  http://localhost:!ND_HTTP!
echo      VNC:  localhost:!ND_VNC!
echo  ---------------------------------------------------

:: Start iproxy tunnels
start "" /b "!IPROXY!" !ND_HTTP!:9999 -u !ND_UDID!
start "" /b "!IPROXY!" !ND_VNC!:5900 -u !ND_UDID!

:: Register USB port after 3s
start "" /b cmd /c "timeout /t 3 /nobreak >nul & curl -s -m 5 "http://localhost:!ND_HTTP!/api/usb/register?ide_url=http://localhost:!ND_HTTP!" >nul 2>&1"

exit /b

:: ════════════════════════════════════════════
:calc_port
if "%1"=="0" (
    set "CALC_PORT=9999"
) else (
    set /a "CALC_PORT=9990 + %1"
)
exit /b
