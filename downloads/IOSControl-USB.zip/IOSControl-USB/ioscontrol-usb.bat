@echo off
setlocal
title IOSControl USB Manager

echo.
echo  IOSControl USB Manager for Windows
echo  ====================================
echo.

set "TOOLS=%~dp0tools"
set "DATA=%USERPROFILE%\.ioscontrol"

if exist "%TOOLS%\iproxy.exe" (
    set "IPROXY=%TOOLS%\iproxy.exe"
    set "DEVID=%TOOLS%\idevice_id.exe"
    set "DEVINFO=%TOOLS%\ideviceinfo.exe"
) else (
    echo [ERROR] Cannot find tools\iproxy.exe
    echo Put iproxy.exe and idevice_id.exe in the tools folder.
    pause
    exit /b 1
)

if not exist "%DATA%\slots" mkdir "%DATA%\slots"
if not exist "%DATA%\active" mkdir "%DATA%\active"

echo [OK] Tools found
echo [..] Scanning for iPhones...
echo.

:LOOP
"%DEVID%" -l > "%TEMP%\icdevs.txt" 2>nul

for /f "usebackq delims=" %%D in ("%TEMP%\icdevs.txt") do (
    if not exist "%DATA%\active\%%D" (
        call :CONNECT %%D
    )
)

for %%F in ("%DATA%\active\*") do (
    call :CHECKDC %%~nxF
)

for %%F in ("%DATA%\slots\*") do (
    call :REREG %%F
)

timeout /t 3 /nobreak >nul
goto LOOP

:CONNECT
setlocal enabledelayedexpansion
set "U=%1"
echo.>"%DATA%\active\%U%"

set "S=0"
for /l %%I in (0,1,99) do (
    set "OK=1"
    for %%X in ("%DATA%\slots\*") do (
        set /p V=<"%%X"
        if "!V!"=="%%I" set "OK=0"
    )
    if "!OK!"=="1" (
        set "S=%%I"
        echo %%I>"%DATA%\slots\%U%"
        goto :GOTSLOT
    )
)
:GOTSLOT
if "!S!"=="0" (set "P=9999") else (set /a "P=9990+!S!")

echo [+] Device connected - Slot !S! - IDE: http://localhost:!P!

start "" /b "%IPROXY%" !P! 9999 %U%
start "" /b cmd /c "timeout /t 4 /nobreak >nul & curl -s -m 5 http://localhost:!P!/api/usb/register?ide_url=http://localhost:!P! >nul 2>&1"
endlocal
exit /b

:CHECKDC
set "C=%1"
findstr /x /c:"%C%" "%TEMP%\icdevs.txt" >nul 2>&1
if errorlevel 1 (
    echo [-] Disconnected: %C:~0,8%...
    del "%DATA%\active\%C%" 2>nul
    del "%DATA%\slots\%C%" 2>nul
)
exit /b

:REREG
setlocal enabledelayedexpansion
set /p RS=<"%1"
if "!RS!"=="0" (set "RP=9999") else (set /a "RP=9990+!RS!")
start "" /b cmd /c "curl -s -m 2 http://localhost:!RP!/api/usb/register?ide_url=http://localhost:!RP! >nul 2>&1"
endlocal
exit /b
